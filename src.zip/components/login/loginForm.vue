<template>
     <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="20px" class="demo-ruleForm">
        <el-form-item prop="uname">
            <el-input type="text" v-model="ruleForm2.uname" auto-complete="off" placeholder="用户名"></el-input>
        </el-form-item>
        <el-form-item prop="Pass">
            <el-input type="password" v-model="ruleForm2.pass" auto-complete="off" placeholder="密码"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
export default {
  data () {
     var validateuname = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入用户名'));
        } else {
          if (this.ruleForm2.uname !== '') {
            this.$refs.ruleForm2.validateField('uname');
          }
          callback();
        }
      };
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.ruleForm2.Pass !== '') {
            this.$refs.ruleForm2.validateField('Pass');
          }
          callback();
        }
      };
      return {
        ruleForm2: {
          pass: '',
          uname: ''
        },
        rules2: {
          pass: [
            { validator: validatePass, trigger: 'blur' }
          ],
          uname: [
            { validator: validateuname, trigger: 'blur' }
          ]
        }
      };
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            alert('submit!');
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
  }
}
</script>
