<template>
    <el-container>
        <el-header>
            <el-row :gutter="20" class="nav" >
                <el-col :lg="4" :sm="4" :xs="12" :offset="2">
                    <div class="grid-content bg-purple">
                        <img src="../../assets/logo/login_kelixun_us.png">
                    </div>
                </el-col>
                <el-col :lg="4" :sm="4" :offset="12" class="holp hidden-xs-only holp" >
                    <div class="grid-content bg-purple">帮助中心</div>
                </el-col>
            </el-row>

        </el-header>
        <el-main class="body">
            <el-row :gutter="20">
                <el-col :lg="6" :sm="6">
                    <div class="grid-content bg-purple">
                        <el-row :gutter="20">
                            <el-col :lg="20" :sm="20"  :offset="16">
                                <p class="title">PoC  集群系统管理平台</p>
                            </el-col>
                        </el-row>
                        <el-row :gutter="20">
                            <el-col :lg="20" :sm="18"   :offset="8">
                                <img src="../../assets/loginbg.png">
                            </el-col>
                        </el-row>
                    </div>
                </el-col>
                <el-col :lg="4"  :sm="4" :offset="8">
                    <div class="grid-content bg-purple">
                        <div class="login">
                        
                        </div>
                    </div>
                </el-col>
            </el-row>
        </el-main>
        <el-footer class="foot">Footer</el-footer>
    </el-container>
</template>

<script>
// import loginFrom from '@/components/login/loginFrom'
export default {
  name: 'Login',
//    components: {
//     loginFrom
//   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .nav{
        font-weight: bold;
        font-size: 16px;
    }
    .holp{
        height:80px;
        line-height: 80px;
        font-size: 20px;
    }
    .logo{
        background-image: url("../../assets/logo/login_kelixun_us.png")
    }
    .body{
        background-color: rgb(21, 120, 174);
        margin-top: 20px;
        padding-top: 135px;
        padding-bottom: 140px;
    }
    p{
        color: #fff;
        font-size: 1.4em;
    }
    .login{
        width: 500px;
        height: 500px;
        border: 2px solid #fff;
        border-radius: 15px
    }
    .foot{
        line-height: 60px
    }
</style>
